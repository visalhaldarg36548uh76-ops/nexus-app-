
# NEXUS RED MAGIC X — Android source project

A cyberpunk-red Android gaming launcher prototype with a separate offline OpenGL ES 2.0 aim-training arena.

## Included
- Android launcher-style home screen with a game library
- Local device dashboard: Android version, model, memory estimate, battery level
- Boost Mode is a safe dashboard preset (Do Not Disturb is not toggled automatically; no hidden process killing or game modification)
- Offline 3D aim arena using OpenGL ES 2.0: moving targets, tap-to-hit scoring, timer, accuracy and best score
- Local preferences for best score and selected preset
- Android 7.0+ baseline (API 24); newer Android versions depend on future SDK/API compatibility

## Build
1. Install Android Studio and JDK 17.
2. Open this folder in Android Studio.
3. Allow Gradle sync.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).

The project uses Android Gradle Plugin 8.6.1 and compile/target SDK 35. If your Android Studio installation does not have SDK 35, install it from SDK Manager.

## Important limits
This is an independent launcher/aim trainer, not a Free Fire MAX modification.
It does not provide auto-aim, enemy tracking/ESP, bullet redirection, injection, anti-cheat bypass, or guaranteed FPS/temperature improvements.
The 3D arena is an offline practice mini-game. The launcher cannot force games to render at 4K/HDR; display quality depends on device, game support, GPU, and Android APIs.
