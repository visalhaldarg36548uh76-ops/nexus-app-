package com.nexus.redmagicx;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.BatteryManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.app.ActivityManager;
import java.util.Locale;

public class MainActivity extends Activity {
    private LinearLayout root;
    private TextView deviceCard, status;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(10, 8, 15));
        getWindow().setNavigationBarColor(Color.rgb(10, 8, 15));
        buildUi();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawableCompat bg(int color, int stroke) {
        return new GradientDrawableCompat(color, stroke, dp(16));
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(24), dp(18), dp(28));
        root.setBackgroundColor(Color.rgb(10, 8, 15));
        scroll.addView(root);
        setContentView(scroll);

        TextView brand = new TextView(this);
        brand.setText("NEXUS");
        brand.setTextColor(Color.rgb(255, 48, 78));
        brand.setTextSize(34);
        brand.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        root.addView(brand);

        TextView sub = new TextView(this);
        sub.setText("RED MAGIC X   //   CYBERPUNK GAMING SYSTEM");
        sub.setTextColor(Color.rgb(191, 183, 202));
        sub.setTextSize(11);
        sub.setLetterSpacing(0.08f);
        root.addView(sub);

        TextView hero = card("HYPER GAMING CONSOLE",
                "Your device. Your profiles. Your practice arena.\nOffline-first • No game modification");
        root.addView(hero, params(-1, -2, 0, 18, 0, 0));

        TextView section = heading("SYSTEM TELEMETRY");
        root.addView(section, params(-1, -2, 0, 20, 0, 8));
        deviceCard = card("", "");
        root.addView(deviceCard, params(-1, -2, 0, 0, 0, 12));
        refreshDeviceCard();

        TextView boost = button("⚡  BOOST MODE  •  BALANCED");
        boost.setOnClickListener(v -> {
            getPreferences(MODE_PRIVATE).edit().putString("preset", "Balanced").apply();
            status.setText("Balanced profile selected. Android controls remain under your control.");
        });
        root.addView(boost, params(-1, -2, 0, 4, 0, 8));

        TextView arena = button("▶  LAUNCH 3D OFFLINE AIM ARENA");
        arena.setOnClickListener(v -> startActivity(new Intent(this, AimArenaActivity.class)));
        root.addView(arena, params(-1, -2, 0, 4, 0, 8));

        TextView refresh = button("↻  REFRESH DEVICE INFO");
        refresh.setOnClickListener(v -> refreshDeviceCard());
        root.addView(refresh, params(-1, -2, 0, 4, 0, 8));

        TextView features = card("ARSENAL / MODULES",
                "01  Game Library & local profiles\n" +
                "02  Device and memory overview\n" +
                "03  Offline 3D aim practice\n" +
                "04  Touch accuracy & reaction score\n" +
                "05  USB device support status\n" +
                "06  Battery and thermal information (where exposed)\n" +
                "07  Local best-score storage\n" +
                "08  Cyberpunk red interface");
        root.addView(features, params(-1, -2, 0, 18, 0, 8));

        status = new TextView(this);
        status.setText("SYSTEM ONLINE  •  LOCAL MODE");
        status.setTextColor(Color.rgb(255, 73, 96));
        status.setTextSize(11);
        status.setPadding(dp(4), dp(14), dp(4), dp(4));
        root.addView(status);
    }

    private void refreshDeviceCard() {
        String model = android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL;
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ((ActivityManager)getSystemService(Context.ACTIVITY_SERVICE)).getMemoryInfo(mi);
        long total = mi.totalMem / (1024 * 1024);
        long avail = mi.availMem / (1024 * 1024);
        int level = -1;
        android.content.Intent battery = registerReceiver(null, new android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (battery != null) {
            int raw = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            if (raw >= 0 && scale > 0) level = Math.round(raw * 100f / scale);
        }
        deviceCard.setText("DEVICE STATUS\n" + model +
                "\nAndroid " + android.os.Build.VERSION.RELEASE + "  •  API " + android.os.Build.VERSION.SDK_INT +
                String.format(Locale.US, "\nRAM: %d MB available / %d MB total", avail, total) +
                "\nBattery: " + (level >= 0 ? level + "%" : "Not reported"));
    }

    private TextView heading(String text) {
        TextView t = new TextView(this); t.setText(text); t.setTextColor(Color.rgb(255, 68, 91));
        t.setTextSize(13); t.setTypeface(Typeface.DEFAULT_BOLD); return t;
    }

    private TextView card(String title, String body) {
        TextView t = new TextView(this);
        t.setText((title == null || title.isEmpty() ? "" : title + "\n") + body);
        t.setTextColor(Color.rgb(237, 231, 244)); t.setTextSize(14);
        t.setPadding(dp(16), dp(16), dp(16), dp(16));
        t.setBackground(new GradientDrawableCompat(Color.rgb(25, 19, 32), Color.rgb(105, 30, 54), dp(16)));
        return t;
    }

    private TextView button(String text) {
        TextView t = new TextView(this); t.setText(text); t.setTextColor(Color.WHITE);
        t.setTextSize(13); t.setTypeface(Typeface.DEFAULT_BOLD); t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), dp(17), dp(14), dp(17));
        t.setBackground(new GradientDrawableCompat(Color.rgb(153, 20, 48), Color.rgb(255, 67, 95), dp(14)));
        return t;
    }

    private LinearLayout.LayoutParams params(int w, int h, int l, int top, int r, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(l, top, r, bottom); return p;
    }

    // Small helper avoids requiring AndroidX or external UI libraries.
    static class GradientDrawableCompat extends android.graphics.drawable.GradientDrawable {
        GradientDrawableCompat(int color, int stroke, float radius) {
            setColor(color); setCornerRadius(radius); setStroke(1, stroke);
        }
    }
}
