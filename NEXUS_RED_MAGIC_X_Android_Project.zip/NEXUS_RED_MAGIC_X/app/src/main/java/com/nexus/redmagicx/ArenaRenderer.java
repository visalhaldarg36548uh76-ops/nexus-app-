package com.nexus.redmagicx;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class ArenaRenderer implements GLSurfaceView.Renderer {
    volatile boolean active = true;
    private int program, posHandle, colorHandle, mvpHandle;
    private final float[] projection = new float[16], view = new float[16], model = new float[16], mvp = new float[16];
    private FloatBuffer cube;
    private long start = System.currentTimeMillis();
    private float targetX = 0f, targetY = 0f;
    private static final String VERT =
        "uniform mat4 uMVP; attribute vec4 aPos; void main(){ gl_Position=uMVP*aPos; }";
    private static final String FRAG =
        "precision mediump float; uniform vec4 uColor; void main(){ gl_FragColor=uColor; }";

    @Override public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        GLES20.glClearColor(0.035f, 0.018f, 0.055f, 1f);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        program = createProgram(VERT, FRAG);
        posHandle = GLES20.glGetAttribLocation(program, "aPos");
        colorHandle = GLES20.glGetUniformLocation(program, "uColor");
        mvpHandle = GLES20.glGetUniformLocation(program, "uMVP");
        float[] vertices = {
            // six independent quad faces (24 vertices)
            -0.5f,-0.5f,-0.5f,  0.5f,-0.5f,-0.5f, 0.5f,0.5f,-0.5f, -0.5f,0.5f,-0.5f,
            -0.5f,-0.5f, 0.5f, -0.5f,0.5f, 0.5f, 0.5f,0.5f, 0.5f,  0.5f,-0.5f,0.5f,
            -0.5f,-0.5f,-0.5f, -0.5f,0.5f,-0.5f, -0.5f,0.5f,0.5f, -0.5f,-0.5f,0.5f,
             0.5f,-0.5f,-0.5f,  0.5f,-0.5f,0.5f,  0.5f,0.5f,0.5f,  0.5f,0.5f,-0.5f,
            -0.5f,-0.5f,-0.5f, -0.5f,-0.5f,0.5f, 0.5f,-0.5f,0.5f, 0.5f,-0.5f,-0.5f,
            -0.5f,0.5f,-0.5f,  0.5f,0.5f,-0.5f, 0.5f,0.5f,0.5f, -0.5f,0.5f,0.5f
        };
        cube = ByteBuffer.allocateDirect(vertices.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        cube.put(vertices).position(0);
        Matrix.setLookAtM(view, 0, 0, 0, 5, 0, 0, 0, 0, 1, 0);
    }

    @Override public void onSurfaceChanged(GL10 gl, int w, int h) {
        GLES20.glViewport(0, 0, w, h);
        float ratio = (float) w / Math.max(1, h);
        Matrix.frustumM(projection, 0, -ratio, ratio, -1, 1, 2, 20);
    }

    @Override public void onDrawFrame(GL10 gl) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
        GLES20.glUseProgram(program);
        long t = System.currentTimeMillis() - start;
        targetX = (float)Math.sin(t / 850.0) * 1.15f;
        targetY = (float)Math.cos(t / 1250.0) * 0.55f;
        drawCube(0, 0, -1.7f, 3.5f, 3.5f, 0.08f, 0.02f, 0.12f, 0.18f);
        drawCube(targetX, targetY, 0, 0.58f, 0.58f, 1f, 0.08f, 0.22f, 1f);
        drawCube(targetX, targetY, 0.35f, 0.16f, 0.16f, 1f, 0.8f, 0.86f, 1f);
    }

    private void drawCube(float x, float y, float z, float sx, float sy, float sz,
                          float r, float g, float b) {
        Matrix.setIdentityM(model, 0);
        Matrix.translateM(model, 0, x, y, z);
        Matrix.scaleM(model, 0, sx, sy, sz);
        float[] mv = new float[16];
        Matrix.multiplyMM(mv, 0, view, 0, model, 0);
        Matrix.multiplyMM(mvp, 0, projection, 0, mv, 0);
        GLES20.glUniformMatrix4fv(mvpHandle, 1, false, mvp, 0);
        GLES20.glUniform4f(colorHandle, r, g, b, 1f);
        cube.position(0);
        GLES20.glEnableVertexAttribArray(posHandle);
        GLES20.glVertexAttribPointer(posHandle, 3, GLES20.GL_FLOAT, false, 0, cube);
        // Six faces rendered as a compact set of triangle fans.
        for (int f = 0; f < 6; f++) GLES20.glDrawArrays(GLES20.GL_TRIANGLE_FAN, f * 4, 4);
        GLES20.glDisableVertexAttribArray(posHandle);
    }

    boolean hitTest(float nx, float ny) {
        // Screen-space practice hit region around the animated target.
        float tx = 0.5f + targetX * 0.19f;
        float ty = 0.5f - targetY * 0.22f;
        float dx = (nx - tx) / 0.09f;
        float dy = (ny - ty) / 0.13f;
        return dx * dx + dy * dy <= 1.0f;
    }

    private int compile(int type, String src) {
        int s = GLES20.glCreateShader(type);
        GLES20.glShaderSource(s, src); GLES20.glCompileShader(s); return s;
    }
    private int createProgram(String v, String f) {
        int p = GLES20.glCreateProgram();
        GLES20.glAttachShader(p, compile(GLES20.GL_VERTEX_SHADER, v));
        GLES20.glAttachShader(p, compile(GLES20.GL_FRAGMENT_SHADER, f));
        GLES20.glLinkProgram(p); return p;
    }
}
