package com.nexus.redmagicx;

import android.app.Activity;
import android.os.Bundle;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.view.Gravity;
import android.graphics.Typeface;
import android.content.SharedPreferences;

public class AimArenaActivity extends Activity {
    private ArenaView arena;
    private TextView hud;
    private long startedAt;
    private int hits = 0, shots = 0;
    private boolean running = true;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        startedAt = System.currentTimeMillis();
        FrameLayout frame = new FrameLayout(this);
        arena = new ArenaView(this);
        frame.addView(arena);
        hud = new TextView(this);
        hud.setTextColor(Color.WHITE); hud.setTextSize(14);
        hud.setTypeface(Typeface.DEFAULT_BOLD);
        hud.setPadding(24, 18, 24, 18);
        hud.setBackgroundColor(0xAA100914);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        frame.addView(hud, hp);
        TextView exit = new TextView(this);
        exit.setText("EXIT  ✕"); exit.setTextColor(Color.WHITE); exit.setTextSize(13);
        exit.setPadding(22, 16, 22, 16); exit.setBackgroundColor(0xCC9B173B);
        FrameLayout.LayoutParams ep = new FrameLayout.LayoutParams(-2, -2, Gravity.RIGHT | Gravity.BOTTOM);
        frame.addView(exit, ep); exit.setOnClickListener(v -> finish());
        setContentView(frame);
        arena.setOnScoreListener((hit, total) -> {
            hits = hit; shots = total;
            runOnUiThread(this::updateHud);
        });
        updateHud();
    }

    private void updateHud() {
        long elapsed = (System.currentTimeMillis() - startedAt) / 1000;
        long left = Math.max(0, 60 - elapsed);
        float accuracy = shots == 0 ? 0 : hits * 100f / shots;
        hud.setText("NEXUS AIM ARENA     TIME " + left + "s     HITS " + hits +
                "     SHOTS " + shots + "     ACC " + String.format("%.0f", accuracy) + "%");
        if (left == 0 && running) {
            running = false;
            int best = getPreferences(MODE_PRIVATE).getInt("best", 0);
            if (hits > best) getPreferences(MODE_PRIVATE).edit().putInt("best", hits).apply();
            hud.append("\nROUND COMPLETE  •  BEST " + Math.max(best, hits) + "  •  TAP EXIT");
            arena.pauseGame();
        }
    }

    interface ScoreListener { void onScore(int hits, int shots); }

    class ArenaView extends GLSurfaceView {
        private final ArenaRenderer renderer;
        private ScoreListener listener;
        ArenaView(android.content.Context c) {
            super(c);
            setEGLContextClientVersion(2);
            renderer = new ArenaRenderer();
            setRenderer(renderer);
            setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
        }
        void setOnScoreListener(ScoreListener l) { listener = l; }
        void pauseGame() { renderer.active = false; }
        @Override public boolean onTouchEvent(MotionEvent e) {
            if (e.getAction() == MotionEvent.ACTION_DOWN && renderer.active) {
                shots++;
                boolean hit = renderer.hitTest(e.getX() / getWidth(), e.getY() / getHeight());
                if (hit) hits++;
                if (listener != null) listener.onScore(hits, shots);
                return true;
            }
            return true;
        }
    }
}
